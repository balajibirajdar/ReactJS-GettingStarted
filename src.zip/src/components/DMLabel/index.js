export { default } from './DMLabel';

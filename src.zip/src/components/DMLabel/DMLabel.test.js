import React from 'react';
import { shallow } from 'enzyme';
import DMLabel from './DMLabel';

describe('<DMLabel />', () => {
  test('renders', () => {
    const wrapper = shallow(<DMLabel />);
    expect(wrapper).toMatchSnapshot();
  });
});

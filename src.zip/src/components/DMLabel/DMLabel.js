import React, { Component } from 'react';
import './DMLabel.css';
class DMLabel extends Component {
  render() {
    return <span className="spanCss">MyCustomLabel</span>;
  }
}

export default DMLabel;

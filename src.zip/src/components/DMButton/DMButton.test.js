import React from 'react';
import { shallow } from 'enzyme';
import DMButton from './DMButton';

describe('<DMButton />', () => {
  test('renders', () => {
    const wrapper = shallow(<DMButton />);
    expect(wrapper).toMatchSnapshot();
  });
});

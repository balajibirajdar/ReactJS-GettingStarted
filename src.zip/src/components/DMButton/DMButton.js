import React, { Component } from 'react';
import './DMButton.css'

class DMButton extends Component {
  render() {
    return <input className="danger" type="button" value="Cancel"></input>;
  }
}

export default DMButton;
